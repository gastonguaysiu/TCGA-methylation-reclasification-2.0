#' Process Beta Values
#'
#' This function reads beta value files from a specified directory, converts
#' beta values to m-values, and saves the results into CSV files.
#' @param main_dir The main directory containing the raw beta value files in a subdirectory named 'raw'.
#' @param output_dir The directory where the output CSV files should be saved.
#' @return Saves two CSV files, one with beta values and another with m-values.
#' @export
process_raw <- function(main_dir, output_dir) {

  raw_path <- file.path(main_dir, "raw")

  logit <- function(beta) {
    ifelse(beta == 0, log(1e-16 / (1 - 1e-16)), ifelse(beta == 1, log((1 - 1e-16) / 1e-16), log(beta / (1 - beta))))
  }

  txt_files <- list.files(path = raw_path, pattern = "\\.txt$", full.names = TRUE)

  unique_df <- data.frame()

  for (i in seq_along(txt_files)) {
    df <- read_delim(txt_files[i], delim = "\t", col_names = FALSE)

    if (i == 1) {
      probe_ids <- df[[1]]
      unique_df <- data.frame(ProbeID = probe_ids)
    }

    file_name <- paste(tools::file_path_sans_ext(basename(txt_files[i])))
    beta_values_col <- df[[2]]
    unique_df[[file_name]] <- beta_values_col
  }

  # Remove rows with any NA values
  unique_df <- na.omit(unique_df)
  colnames(unique_df) <- gsub(".level3betas", ".level3betas.txt", colnames(unique_df))

  write.csv(unique_df, file.path(output_dir, "beta_val_all.csv"), row.names = FALSE)

  unique_df[-1] <- apply(unique_df[-1], 2, logit)

  row.names(unique_df) <- unique_df[,1]
  unique_df <- unique_df[,-1]

  write.csv(unique_df, file.path(output_dir, "m_val_all.csv"), row.names = TRUE)

}


#' Organize Directories
#'
#' This function creates a new directory and then moves specified subdirectories into it.
#' It's particularly designed to move directories with names starting with 'conv' and a specific 'e0' directory.
#' @param main_dir The main directory where the new directory will be created and from where existing directories will be moved.
#' @param sub_dir_name Name for the new directory to create and move directories into.
#' @param e0_dir Name of the specific directory to move separately into the new directory.
#' @export
#'
organize_directories <- function(main_dir, sub_dir_name, e0_dir) {
  # Ensure working in the correct main directory
  setwd(main_dir)

  # Create a new directory
  new_dir_path <- file.path(main_dir, sub_dir_name)
  if (!dir.exists(new_dir_path)) {
    dir.create(new_dir_path)
  } else {
    cat("Directory already exists:", new_dir_path, "\n")
  }

  # Move the target directory to the new directory
  target_dir_path <- file.path(main_dir, e0_dir)
  if (dir.exists(target_dir_path)) {
    new_target_dir_path <- file.path(new_dir_path, e0_dir)
    if (file.rename(target_dir_path, new_target_dir_path)) {
    } else {
      cat("Failed to move", e0_dir, "to", new_dir_path, "\n")
    }
  } else {
    cat(e0_dir, "directory does not exist.\n")
  }

  # Find and move all 'conv*' directories
  conv_dirs <- list.files(pattern = "^conv.*", full.names = TRUE, include.dirs = TRUE)
  for (dir in conv_dirs) {
    if (dir.exists(dir)) {
      new_conv_dir_path <- file.path(new_dir_path, basename(dir))
      if (file.rename(dir, new_conv_dir_path)) {
        cat("Moved", dir, "to", new_dir_path, "\n")
      } else {
        cat("Failed to move", dir, "to", new_dir_path, "\n")
      }
    }
  }
}

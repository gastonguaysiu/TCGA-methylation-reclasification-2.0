#' Process Data and Create Folders
#'
#' This function processes data by reading and manipulating CSV files, performs clustering, score calculations,
#' and then creates specific directories to store modified files. It loops through a series of steps to
#' manipulate data and save the results in new directories.
#' @param main_dir The main directory where the input files are located and where the directories will be created.
#' @param m_val_file Name of the CSV file containing m values.
#' @param em_see_outpath Name of the CSV file containing em_see values.
#' @param ref_file Name of the CSV file containing reference values.
#' @param num_conv the number of instances for convergences
#' @param em_stop the number of convergences needed to stop scoring
#' @param update_time the number of convergences needed to stop scoring
#' @return Saves a CSV file named as specified in 'main_dir'.
#' @export
#'
#'
ml1 <- function(main_dir, m_val_file, em_see_outpath, ref_file,
                                     num_conv, em_stop, update_time) {

  setwd(main_dir)

  calculate_scores <- function(df, cluster_id) {
    df <- df %>%
      filter(cluster == cluster_id, Sample_Type == "Primary Tumor") %>%
      mutate(live_score = as.numeric(days_to_last_follow_up) / live_score_constant,
             death_score = as.numeric(days_to_death) / death_score_constant)
  }

  update_probe_values <- function(em_see, y, num_e0_probes, nprobes) {
    set.seed(floor(runif(1, min = 0, max = (y * 10))))
    neg_probes = floor(runif(1, min = 0, max = (num_e0_probes / 2)))
    pos_probes = floor(runif(1, min = 0, max = (min((num_e0_probes / 2), (nprobes - num_e0_probes)))))

    # Find indices of 0s and 1s
    zero_indices <- which(em_see$new == 0)
    one_indices <- which(em_see$new == 1)

    # Sample and update for adding probes
    if (length(zero_indices) >= pos_probes && pos_probes > 0) {
      indices_to_update <- sample(zero_indices, pos_probes)
      em_see$new[indices_to_update] <- 1
    }

    # Sample and update for removing probes
    if (length(one_indices) >= neg_probes && neg_probes > 0) {
      indices_to_update <- sample(one_indices, neg_probes)
      em_see$new[indices_to_update] <- 0
    }

    return(em_see)
  }

  # em_see <- update_probe_values(em_see, y, num_e0_probes, nprobes)

  process_clusters <- function(notes, calculate_scores) {
    mxcls <- lapply(1:3, calculate_scores, df = notes)

    nx <- data.frame(samples = vapply(mxcls, nrow, numeric(1)),
                     dead = vapply(mxcls, function(df) sum(df$vital_status == "Dead"), numeric(1)),
                     live_weight = vapply(mxcls, function(df) sum(df$live_score, na.rm = TRUE), numeric(1)),
                     dead_weight = 0.01)

    total_dead <- sum(nx$dead)

    nx <- nx %>%
      dplyr::mutate(cluster = row_number()) %>%
      dplyr::mutate(dead = if_else(dead == 0, 0.01, dead),
                    dead_weight = if_else(dead > 0, if_else(vapply(mxcls, function(df) sum(df$death_score, na.rm = TRUE), numeric(1)) == 0, 0.01, vapply(mxcls, function(df) sum(df$death_score, na.rm = TRUE), numeric(1))), dead_weight),
                    ratio = dead / samples,
                    precision = dead / (dead + live_weight),
                    recall = dead / total_dead,
                    final_score = if_else((precision + recall) == 0, 0, 2 * (precision * recall) / (precision + recall)),
                    rscore = ratio * dead_weight)

    nx <- dplyr::arrange(nx, final_score)
    nxa <- nx
    nx <- dplyr::arrange(nx, rscore)
    nxb <- nx

    return(list(nxa = nxa, nxb = nxb))
  }

  # result <- process_clusters(notes, calculate_scores)
  # nxa <- result$nxa
  # nxb <- result$nxb

  current_time <- Sys.time()  # Update the current time at the start of the loop
  last_print <- current_time

  for (i in 1:num_conv) {

    print("building reference")

    # Load and process the m_val_all.csv file
    CpG <- read_csv(file.path(main_dir, m_val_file))
    CpG <- as.data.frame(CpG)
    rownames(CpG) <- CpG[,1]

    # Load and process the em_see.csv file
    em_see <- read.csv(file.path(main_dir, em_see_outpath))
    nprobes <- nrow(em_see)
    num_e0_probes <- sum(em_see$e0)
    em_see$new <- em_see$e0

    new <- em_see %>%
      select(master_list, new) %>%
      mutate(new = if_else(new == 0, NA_real_, new)) %>%
      na.omit() %>%
      select(-new) %>%
      setNames("Name")

    mx <- merge(x = new, y = CpG, by.x = "Name", by.y = "...1") %>%
      select(-1)

    set.seed(42)
    clusters <- tibble(sample = colnames(mx),
                       cluster = kmeans(t(mx), 3, iter.max = 10000)$cluster)

    # Load the reference file (e.g., ref4.csv)
    ref <- read.csv(file.path(main_dir, ref_file))
    notes <- merge(x = ref, y = clusters, by.x = "File_Name", by.y = "sample")

    live_score_constant = median(unique(ref$days_to_death), na.rm = TRUE)
    death_score_constant = median(unique(ref$days_to_last_follow_up), na.rm = TRUE)

    result <- process_clusters(notes, calculate_scores)
    nxa <- result$nxa
    nxb <- result$nxb

    write.csv(nxa, file.path(main_dir, "na_best.csv"), row.names = FALSE)
    write.csv(nxb, file.path(main_dir, "nb_best.csv"), row.names = FALSE)

    folder_name <- "e0"
    temp <- file.path(main_dir, "e0")
    files_to_copy <- c("em_see.csv", "na_best.csv", "nb_best.csv", "m_val_all.csv")
    if (!dir.exists(folder_name)) {
      dir.create(file.path(main_dir, folder_name))

      write.csv(notes, file.path(main_dir, "notes_e0.csv"), row.names = FALSE)
      files_to_copy <- c("em_see.csv", "na_best.csv", "nb_best.csv", "m_val_all.csv", "notes_e0.csv")

      for (file_name in files_to_copy) {
        file.copy(file.path(main_dir, file_name), file.path(temp, file_name))
      }
      cat("e0 Files copied successfully!\n")
    } else {
      for (file_name in files_to_copy) {
        file.copy(file.path(temp, file_name), file.path(main_dir, file_name))
      }
    }

    #########################################################################

    new_best <- 2
    num_sim <- em_stop
    counter <- num_sim
    y <- 1

    print("prunning down the probes")

    while ( counter != 0 ) {

      if ( y > em_stop ) {
        y <- 1
        counter <- num_sim
      }

      # Load and process the em_see.csv file
      em_see <- read.csv(file.path(main_dir, em_see_outpath))
      nprobes <- nrow(em_see)
      num_e0_probes <- sum(em_see$e0)
      em_see$new <- em_see$e0

      em_see <- update_probe_values(em_see, y, num_e0_probes, nprobes)

      new <- em_see %>%
        select(master_list, new) %>%
        mutate(new = if_else(new == 0, NA_real_, new)) %>%
        na.omit() %>%
        select(-new) %>%
        setNames("Name")

      mx <- merge(x = new, y = CpG, by.x = "Name", by.y = "...1") %>%
        select(-1)

      set.seed(42)
      clusters <- tibble(sample = colnames(mx),
                         cluster = kmeans(t(mx), 3, iter.max = 10000)$cluster)

      notes <- merge(x = ref, y = clusters, by.x = "File_Name", by.y = "sample")

      result <- process_clusters(notes, calculate_scores)
      nxa <- result$nxa
      nxb <- result$nxb

      na_best <- read.csv(file.path(main_dir, "na_best.csv"))
      nb_best <- read.csv(file.path(main_dir, "nb_best.csv"))

      if (round(nxa$final_score[3], 5) > round(na_best$final_score[3], 5) |
          (round(nxa$final_score[3], 5) >= round(na_best$final_score[3], 5) & round(nxb$rscore[1], 7) < round(nb_best$rscore[1], 7)) |
          (round(nxa$final_score[3], 5) >= round(na_best$final_score[3], 5) & round(nxb$rscore[1], 7) <= round(nb_best$rscore[1], 7) & nrow(new) < num_e0_probes)) {
        write.csv(nxa, file.path(main_dir, "na_best.csv"), row.names = FALSE)
        write.csv(nxb, file.path(main_dir, "nb_best.csv"), row.names = FALSE)

        em_see2 <- em_see[,c(1,3)]
        colnames(em_see2) <- c("master_list", "e0")
        write.csv(em_see2, em_see_outpath, row.names = FALSE)

        current_time <- Sys.time()  # Update the current time at the start of the loop
        if (difftime(current_time, last_print, units = "secs") >= update_time) {
          print("prunning down the probes")
          print("found new set of probes, updating scores")
          print(paste("e", y, " is best", sep = ""))
          last_print <- current_time  # Update the last print time
        }

      } else {
        counter <- counter - 1
      }

      y <- y +1
    }

    #########################################################

    counter <- num_sim
    print("adding probes to enhance robustness")

    while ( counter != 0 ) {

      if ( y > em_stop ) {
        y <- 1
        counter <- num_sim
      }

      # Load and process the em_see.csv file
      em_see <- read.csv(file.path(main_dir, em_see_outpath))
      nprobes <- nrow(em_see)
      num_e0_probes <- sum(em_see$e0)
      em_see$new <- em_see$e0

      em_see <- update_probe_values(em_see, y, num_e0_probes, nprobes)

      new <- em_see %>%
        select(master_list, new) %>%
        mutate(new = if_else(new == 0, NA_real_, new)) %>%
        na.omit() %>%
        select(-new) %>%
        setNames("Name")

      mx <- merge(x = new, y = CpG, by.x = "Name", by.y = "...1") %>%
        select(-1)

      set.seed(42)
      clusters <- tibble(sample = colnames(mx),
                         cluster = kmeans(t(mx), 3, iter.max = 10000)$cluster)

      notes <- merge(x = ref, y = clusters, by.x = "File_Name", by.y = "sample")

      result <- process_clusters(notes, calculate_scores)
      nxa <- result$nxa
      nxb <- result$nxb

      na_best <- read.csv(file.path(main_dir, "na_best.csv"))
      nb_best <- read.csv(file.path(main_dir, "nb_best.csv"))

      if (round(nxa$final_score[3], 5) > round(na_best$final_score[3], 5) |
          (round(nxa$final_score[3], 5) >= round(na_best$final_score[3], 5) & round(nxb$rscore[1], 7) < round(nb_best$rscore[1], 7)) |
          (round(nxa$final_score[3], 5) >= round(na_best$final_score[3], 5) & round(nxb$rscore[1], 7) <= round(nb_best$rscore[1], 7) & nrow(new) > num_e0_probes)) {
        write.csv(nxa, file.path(main_dir, "na_best.csv"), row.names = FALSE)
        write.csv(nxb, file.path(main_dir, "nb_best.csv"), row.names = FALSE)

        file.remove("em_see.csv")
        em_see2 <- em_see[,c(1,3)]
        colnames(em_see2) <- c("master_list", "e0")
        write.csv(em_see2, em_see_outpath, row.names = FALSE)

        current_time <- Sys.time()  # Update the current time at the start of the loop
        if (difftime(current_time, last_print, units = "secs") >= update_time) {
          print("adding probes to enhance robustness")
          print("found new set of probes, updating scores")
          print(paste("e", y, " is best", sep = ""))
          last_print <- current_time  # Update the last print time
        }

      } else {
        counter <- counter - 1
      }

      y <- y +1
    }

    ##################################################

    folder_name <- paste0("conv", i)
    if (!dir.exists(folder_name)) {
      dir.create(folder_name)
    }

    for (file_name in files_to_copy) {
      temp <- file.path(main_dir, folder_name)
      file.copy(file_name, file.path(temp, file_name))
    }
    cat("Files copied successfully!\n")

    see <- read.csv(file.path(main_dir, em_see_outpath))
    CpG <- read_csv(file.path(main_dir, m_val_file))

    see2 <- subset(see, e0 == 0)
    see2$e0 <- 1

    CpG <- merge(x=see2, y=CpG, by.x="master_list", by.y="...1", all = FALSE)
    rownames(CpG) <- CpG[,1]
    CpG <- CpG[,-c(1,2)]

    write.csv(see2, em_see_outpath, row.names = FALSE)
    write.csv(CpG, file.path(main_dir, "m_val_all.csv"), row.names = TRUE)

  }

}

#' Create em_see original
#'
#' This function creates a master list from the row names of a given data frame,
#' adds a constant column 'e0' with a value of 1, and saves the result to a CSV file.
#' @param main_dir The main directory containing the m_vall_all.csv files
#' @return Saves the original em_see.csv file.
#' @export
#'
create_e0 <- function(main_dir) {

  CpG <- read_csv(file.path(main_dir, "m_val_all.csv"))
  CpG <- as.data.frame(CpG)

  em_see <- as.data.frame(CpG[,1])
  colnames(em_see) <- "master_list"
  em_see$e0 <- 1

  write.csv(em_see, file.path(main_dir, "em_see.csv"), row.names = FALSE)
}

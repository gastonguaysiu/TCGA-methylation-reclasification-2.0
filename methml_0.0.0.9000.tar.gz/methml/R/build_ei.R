
#' Copy and Rename Specific Files in Subdirectories
#'
#' This function iteratively searches through subdirectories of a specified directory,
#' looking for a specific file ('em_see.csv'). When found, it copies this file to a
#' new directory and renames it based on the subdirectory name.
#'
#' @param main_dir The main directory under which the target and destination directories are located.
#' @param sub_dir_name Name of the subdirectory containing target directories.
#' @param target_file_name Name of the file to search and copy.
#' @param temp_dir Name of the new directory where files will be copied and renamed.
#' @export
#'
build_ei <- function(main_dir, sub_dir_name, target_file_name, temp_dir) {
  # Construct paths for the overall process
  conv_path <- file.path(main_dir, sub_dir_name)
  see_dir <- file.path(main_dir, temp_dir)

  # Create the new directory if it doesn't exist
  if (!dir.exists(see_dir)) {
    dir.create(see_dir)
  }

  # List all directories starting with 'conv' within the specified subdirectory
  setwd(conv_path)
  conv_dirs <- list.files(pattern = "^conv.*", full.names = TRUE, include.dirs = TRUE)

  # Iterate over each directory, find the target file, copy and rename it
  for (dir in conv_dirs) {
    # Define the source file path
    source_file <- file.path(conv_path, dir, target_file_name)

    # Check if the file exists
    if (file.exists(source_file)) {
      # Define the new file name based on the directory name and copy the file
      new_file_name <- paste0(basename(dir), "_", target_file_name)
      dest_file <- file.path(see_dir, new_file_name)

      # Copy the file to the new directory with the new name
      file.copy(source_file, dest_file)
    }
  }

  # Iterate over each file, read it, and store it in the list
  list_of_dfs <- list()
  for (i in 1:length(conv_dirs)) {
    file_path <- file.path(see_dir, paste0(conv_dirs[[i]], "_", target_file_name))
    if (file.exists(file_path)) {
      temp_df <- read.csv(file_path, stringsAsFactors = FALSE)
      # Store the data frame in the list
      list_of_dfs[[i]] <- temp_df
    }
  }

  # Combine all data frames using a full join; assuming 'master_list' is the common column
  combined_df <- reduce(list_of_dfs, full_join, by = "master_list")
  combined_df[, -1] <- sapply(combined_df[, -1], function(x) as.numeric(as.character(x)))
  combined_df$here <- rowSums(combined_df[, -1], na.rm = TRUE)
  em_see0_updated <- data.frame(master_list = combined_df$master_list, e0 = combined_df$here)
  write.csv(em_see0_updated, file.path(main_dir, target_file_name), row.names = FALSE)

  e0_path <- file.path(conv_path, "e0")

  # Correctly check if the file exists
  full_file_path <- file.path(e0_path, "m_val_all.csv")
  file.remove(file.path(main_dir, "m_val_all.csv"))
  file.copy(full_file_path, file.path(main_dir, "m_val_all.csv"))
}
